//
//  ViewController.swift
//  TwiterDemo
//
//  Created by jabeed on 07/11/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btnlogin: UIButton!
    
    @IBOutlet weak var btnlogout: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        FHSTwitterEngine.shared()?.permanentlySetConsumerKey("0C1KMEGi6Tp1L54q38mE8wqwo", andSecret: "oWxdtYgaKbfVjwPxdKLLpw13jtWR1VfcPuqTsJW5amOSGWfzMC")
    }

    @IBAction func loginButtonAction(_ sender: UIButton) {
        
        let login = FHSTwitterEngine.shared().loginController { (success) in
            self.btnlogin.isHidden = true
            self.btnlogout.isHidden = false
            } as UIViewController
        self.present(login, animated: true, completion: nil)
    }
    @IBAction func logoutButtonAction(_ sender: UIButton) {
       
        
        FHSTwitterEngine.shared()?.clearAccessToken()
        self.btnlogin.isHidden = false
        self.btnlogout.isHidden = true
    }
}

